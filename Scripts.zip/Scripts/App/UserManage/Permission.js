﻿app.controller("PermissionController", ['$scope', '$http', '$rootScope', function ($scope, $http, $rootScope) {

    $rootScope.$on("LoadPermissionTab", function () {
        if ($scope.ddlUserRoles.dataSource.data().length == 0) {
            $scope.ddlUserRoles.dataSource.read();
        }
        if ($scope.grdPermissionGrid.dataSource.data().length >= 0) {
            $scope.search = "";
            $scope.ddlUserRoles.dataSource.read();
        }

    });
    $scope.getPermissonGridUpdatedColumns = function () {
        return $.grep($scope.grdPermissionGrid.dataSource.data(), function (item) {
            return item.dirty
        });
    }

    $scope.ddlUserRoleOptions = {
        dataSource: {
            transport: {
                read: {
                    type: "Get",
                    dataType: "json",
                    async: false,
                    url: "/api/Role/GetAll?Id=0",
                    complete: function (response) {
                        $scope.grdPermissionGrid.dataSource.read();
                    }
                }
            }
        },
        dataTextField: "Name",
        dataValueField: "RoleId",
        select: function (e) {
            if ($scope.getPermissonGridUpdatedColumns().length > 0 && !confirm("Are you sure you want to cancel the changes ?")) {
                e.preventDefault();
                e.sender.close();
                return false;
            }

        },
    };

    $scope.RoleonChange = function (e) {
        $scope.grdPermissionGrid.dataSource.read();
    };

    $scope.grdPermissionGridOptions = {
        dataSource: {
            transport: {
                read: {
                    type: "get",
                    dataType: "json",
                    url: function () {
                        return "/api/Permission/GetPermissionsByRoleId?roleId=" + $scope.ddlUserRoles.value();
                    },
                    error: function (xhr, error) {
                        console.debug(xhr); console.debug(error);
                    },
                }
            },
            group: [{ field: "ModuleName", dir: "asc" }],
            serverSorting: false,
            serverFiltering: false,
            serverGrouping: false,
            batch: true,
            schema: {
                data: function (response) {
                    if (response && response.Result) {
                        return response.Result;
                    }
                    return [];
                },
                total: 'Total',
                model: {
                    id: "PermissionId",
                    fields: {
                        IsPermitted: { type: "boolean", editable: true }
                    }
                }
            }
        },
        autobind: false,
        pageable: false,
        height: 470,
        sortable: true,
        groupable: false,
        editable: true,
        dataBound: function () {
            var grid = $scope.grdPermissionGrid;
            grid.table.find(".k-grouping-row").each(function () {
                grid.collapseGroup(this);
            });
        },
        edit: function (e) {
            if (e.container.find("input[name=IsPermitted]").length > 0) {
                e.container.find("input[name=IsPermitted]").click();
            }
            else {
                e.container.find("input[name='Name']").each(function () { $(this).attr("disabled", "disabled") });
                e.container.find("input[name='Desc']").each(function () { $(this).attr("disabled", "disabled") });
            }
        },
        columns: [

                { field: "ModuleName", title: "Module Name", hidden: true },
                { field: "Name", title: "{{'Name' | translate}}", readOnly: true, editable: false, width: "30%" },
                { field: "Desc", title: "{{'Description' | translate}}", readOnly: true, editable: false, width: "50%" },
                { field: "IsPermitted", title: " ", width: "20%", sortable: false, template: "<input type='checkbox' name = 'IsPermitted'  onclick=\"permission_OnClick(this)\" " + "# if (IsPermitted) { # " + "checked='checked'" + "# } #" + "/>", headerTemplate: "<input id  = \"masterCheckBox\" onclick=\"SelectAllCheckBoxes(this)\" type='checkbox'/>" }
        ],
    };


    $scope.SavePermissionChanges = function () {
        var model = $scope.getPermissonGridUpdatedColumns();
        if (model.length > 0) {
            $http({
                method: 'POST',
                url: ApiUrl + "/api/Permission/Update",
                data: JSON.stringify($scope.getPermissonGridUpdatedColumns())
            }).then(function successCallback(response) {
                $scope.grdPermissionGrid.dataSource.read();
                SetMessage("Update");
            }, function errorCallback(response) {
                OnError(response);
            });
        }
    };
}]);

function SelectAllCheckBoxes(obj) {
    var checkboxes = $("input[name=IsPermitted]");
    var masterChecked = $('#masterCheckBox').is(':checked');
    for (var i = 0; i < checkboxes.length; i++) {
        if (masterChecked && !checkboxes[i].checked) {
            $(checkboxes[i]).click();
        }
        if (!masterChecked && checkboxes[i].checked) {
            $(checkboxes[i]).click();
        }
    }

    $(document).click();
}
function permission_OnClick(obj) {
    $(obj).parent().click();
    $(document).click();
}