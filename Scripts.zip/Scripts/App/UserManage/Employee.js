﻿app.controller("EmployeeController", ['$scope', '$http', '$rootScope', function ($scope, $http, $rootScope) {
    $scope.search = "";
    var KEY_NAME = "EmployeeID";
    Schema = "Employee";
    $scope.isDisabled = false;
    debugger;
    $rootScope.$on("LoadEmployeeTab", function () {

        if ($scope.grdEmployeeGrid.dataSource.data().length == 0) {
            $scope.grdEmployeeGrid.dataSource.read();
        }
        if ($scope.grdEmployeeGrid.dataSource.data().length >= 0) {
            $scope.search = "";
            $scope.cmbGender.dataSource.read();
            $scope.grdEmployeeGrid.dataSource.read();
        }
    });

    $scope.popUp = function (e) {
        e.preventDefault();
        $("span.k-tooltip-validation").hide();
        var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
        $scope.cmbGender.dataSource.read();
        $scope.cmbMaritalStatus.dataSource.read();
        $scope.employee = dataItem == null ? {} : jQuery.extend({}, dataItem);
        $scope.employee.EmployeeNumber = $scope.employee.EmployeeNumber;
        $scope.FirstNameLength = false;
        $scope.UserNameLength = false;
        $scope.isDisabled = false;
        if (!dataItem) {
            $scope.IsVisible = $scope.employee.IsApplicationUser;
            angular.element(document.querySelector('#Password')).prop('required', false);
            angular.element(document.querySelector('#UserName')).prop('required', false);
        }
        else {
            $scope.employee.DateOfBirth = ($scope.employee.DateOfBirth != null) ? kendo.toString(new Date(dataItem.DateOfBirth), "MM/dd/yyyy") : "";
            $scope.employee.DateOfJoining = ($scope.employee.DateOfJoining != null) ? kendo.toString(new Date(dataItem.DateOfJoining), "MM/dd/yyyy") : "";

            $scope.cmbGender.value($scope.employee.Gender);
            $scope.cmbMaritalStatus.value($scope.employee.MaritalStatus);
            $scope.IsVisible = $scope.employee.IsApplicationUser;
            if ($scope.employee.IsApplicationUser == false) {
                angular.element(document.querySelector('#UserName')).prop('required', false);
                angular.element(document.querySelector('#Password')).prop('required', false);
            }
        }
        // Show or Hide UserName & Password textboxes 
        $scope.HideTextBox = function () {
            $scope.IsVisible = $scope.employee.IsApplicationUser;

            var UserNameRequiredTrue = angular.element(document.querySelector('#UserName')).prop('required', true);
            var UserNameRequiredFalse = angular.element(document.querySelector('#UserName')).prop('required', false);
            var PasswordRequiredTrue = angular.element(document.querySelector('#Password')).prop('required', true);
            var PasswordRequiredFalse = angular.element(document.querySelector('#Password')).prop('required', false);

            ($scope.IsVisible == true) ? UserNameRequiredTrue : UserNameRequiredFalse;
            ($scope.IsVisible == true) ? PasswordRequiredTrue : PasswordRequiredFalse;
        }
        $scope.$apply();
        $scope.winOptions = {
            title: dataItem == null ? "Add" : "Update",
        }
        $scope.employeeConfigwindow.setOptions($scope.winOptions);
        $scope.employeeConfigwindow.open().center();
    };

    $scope.changeStatus = function (e) {
        e.preventDefault();
        var model = this.dataItem($(e.currentTarget).closest("tr"));
        model = jQuery.extend({}, model);
        var target = model.IsActive ? false : true;
        var warnText = target == false ? Constants.MSG_DEACTIVATE : Constants.MSG_ACTIVATE;
        //$.when(showConfirmationWindow(warnText)).then(function (confirmed) {
        //if (confirmed) {
        model.IsActive = target;

        $http({
            method: 'Post',
            url: ApiUrl + '/api/Employee/SetStatus',
            data: model
        }).then(function successCallback(response) {
            if (response != null && response.data == "CantChange") {
                WarnMessage("Cannot deactivate " + model.FirstName + " as there are active schedules");
            }
            else {
                var dataItem = $scope.grdEmployeeGrid.dataSource.get(model[KEY_NAME]);
                dataItem.set("IsActive", target);
                $scope.grdEmployeeGrid.refresh();
            }

        }, function errorCallback(response) {
            OnError(response);
        });
        //}
        //});
    };

    $scope.getOktaUser = function (e) {
        showloader();
        $http(
            {
                method: 'Post',
                url: ApiUrl + '/api/Employee/getAllOktaUsers',
                data: { apiKey: ApiToken, siteUrl: OktaUrl }
            }).then(function successCallback(response) {
                hideloader();
                WarnMessage("Users updated");
            }).then(function errorCallback(response) {
                hideloader();
            })
    };

    $scope.delete = function (e) {
        e.preventDefault();
        var model = this.dataItem($(e.currentTarget).closest("tr"));
        var warnText = Constants.MSG_DELETE;
        $.when(showConfirmationWindow(warnText)).then(function (confirm) {
            if (confirm) {

                $http({
                    method: "Post",
                    url: ApiUrl + "/api/Employee/Delete",
                    data: model
                }).then(function successCallback(response) {
                    console.log("For Delete" + response);
                    $scope.grdEmployeeGrid.refresh();
                    SetMessage("Delete");
                    $scope.grdEmployeeGrid.dataSource.read();
                },
                function errorCallback(response) {
                    OnError(response);
                });
            }
        });
    }

    //Get: Entity activity Log details
    $scope.auditTrial = function (id) {
        GetAudit(Schema, id);
    };


    $scope.grdEmployeeGridOptions = {
        dataSource: {
            transport: {
                read: {
                    type: "POST",
                    url: function () {
                        return "/api/Employee/Search"
                    },
                    complete: function (response) {
                        hideloader();
                    }
                },
                parameterMap: function (options, operation) {
                    var opt = {};
                    opt = options;
                    opt.search = $scope.search;
                    return opt;
                }
            },
            schema: {
                data: function (response) {
                    if (response && response.Result) {
                        return response.Result;
                    }
                    return [];
                },
                total: 'Total',
                model: {
                    id: KEY_NAME
                }
            },
            serverPaging: true,
            serverSorting: true,
            pageSize: 10
        },
        pageable: true,
        sortable: true,
        sortable: {
            allowUnsort: false
        },
        dataBound: OnKendoDataBound,
        columns: [
            { field: "EmployeeID", title: "EmployeeID", width: 80, hidden: true },
            {
                field: "FullName", title: "{{'Name' || translate}}", width: "220px", template: "<a  id='tempId' ng-click='auditTrial(#=EmployeeID#)' style='cursor: pointer;'>{{dataItem.FullName}}</a>"
            },
            {
                field: "Email", title: "{{'Email' || translate}}", width: "220px"
            },
            {
                command: [
                  { name: "editt", text: "<i class='k-icon k-edit'></i>", click: $scope.popUp },
                  {
                      name: "deactivate", text: "<label class='checkbox checkbox-slider--b-flat'><input type='checkbox' checked><span></span></label>", click: $scope.changeStatus
                  },
                  {
                      name: "activate", text: "<label class='checkbox checkbox-slider--b-flat'><input type='checkbox' ><span></span></label>", click: $scope.changeStatus
                  },
                  //{ name: "deletee", text: "<i class='glyphicon glyphicon-trash'></i>", click: $scope.delete }
                ], title: "{{ 'Action' | translate }}", width: "140px", headerTemplate: '<label class="greenHeader">Action</label>'
            }
        ],
        //editable: "popup",
        toolbar: [{ name: "editt", text: "<i class='k-icon k-add'></i>{{ 'Add Employee' }}" }]
    }


    $scope.cmbGenderOptions = {
        dataSource: {
            transport: {
                read: {
                    contentType: "application/json",
                    type: "Get",
                    url: function () {
                        return "/api/Employee/GetGenderList"
                    },
                    error: function (xhr, error) {
                        console.debug(xhr); console.debug(error);
                    }
                }
            },
            schema: {
                model: {
                    id: 'Value'
                }
            },
        },
        change: function (e) {
        },
        placeholder: "Select Gender...",
        dataTextField: "Name",
        dataValueField: "Value",
        filter: "contains"
    };

    $scope.cmbMaritalStatusOptions = {
        dataSource: {
            transport: {
                read: {
                    contentType: "application/json",
                    type: "Get",
                    url: function () {
                        return "/api/Employee/GetMaritalStatusList"
                    },
                    error: function (xhr, error) {
                        console.debug(xhr); console.debug(error);
                    }
                }
            },
            schema: {
                model: {
                    id: 'Value'
                }
            },
        },
        change: function (e) {
        },
        placeholder: "Select Status...",
        dataTextField: "Text",
        dataValueField: "Value",
        filter: "contains"
    };

    $scope.dtOptions = {
        format: "MM/dd/yyyy",
        parseFormats: ["MM/dd/yyyy"]
    };

    $scope.submit = function () {
        $scope.isDisabled = true;
        if ($scope.validator.validate()) {

            if (parseInt($('#cmbGender').val()) == NaN) {
                $scope.employee.Gender = null;
            }
            if (parseInt($('#cmbGender').val()) == NaN) {
                $scope.employee.Gender = null;
            }

            if ($('#FirstName').val().length < 1) {
                //$scope.BlankFirstName = true;
                angular.element(document.querySelector('#FirstName')).prop('required', true);
                $scope.FirstNameLength = true;
                $scope.isDisabled = false;
                return false;
            }

            if ($scope.employee.IsApplicationUser == true) {
                angular.element(document.querySelector('#Password')).prop('required', true);
                angular.element(document.querySelector('#UserName')).prop('required', true);

                if ($('#UserName').val() == "" || $('#Password').val() == "") {
                    return false;
                }
                var UserNameLength = $('#UserName').val().length;
                if (UserNameLength == 1 || UserNameLength == 2) {
                    $scope.UserNameLength = true;
                    return false;
                }
            }

            if ($scope.employee.IsApplicationUser == false) {
                angular.element(document.querySelector('#Password')).prop('required', false);
                angular.element(document.querySelector('#UserName')).prop('required', false);
            }

            if ($scope.employee.IsApplicationUser == null) {
                $scope.employee.IsApplicationUser = false;
            }

            var model = $scope.employee;
            //showloader();
            //$http.pendingRequests.length = 1;

            $http({
                method: 'Post',
                url: ApiUrl + ($scope.employee[KEY_NAME] == null ? '/api/Employee/Add' : '/api/Employee/update'),
                data: model
            }).then(function successCallback(response) {
                //hideloader();
                //$http.pendingRequests.length = 0;
                $("#DateOfBirth").data('kendoDatePicker').value(model.DateOfBirth);
                $("#DateOfJoining").data('kendoDatePicker').value($scope.employee.DateOfJoining);

                //if (response != null && response.data == "exist") {
                //    WarnMessage("Employee " + model.FirstName + " " + (model.MiddleName != null ? model.MiddleName : "") + " already exists!");
                //    return;
                //}

                //if (response.data == "EmailExists") {
                //    WarnMessage("This Email " + model.Email + " is already taken!");
                //    return;
                //}
                if (response.data == "UserExists") {
                    WarnMessage("This Username " + model.UserName + " is already taken!");
                    return;
                }

                if (response != null && response.data != "") {
                    $scope.employeeConfigwindow.close();
                    var temp = response.data;
                    if (temp.IsActive == false && model.EmployeeID == null) {
                        $scope.employee[KEY_NAME] == temp.EmployeeId;
                        var target = temp.IsActive ? false : true;
                        var warnText = target == false ? Constants.MSG_DEACTIVATE : Constants.MSG_REACTIVATE;
                        $.when(showConfirmationActiveWindow(warnText)).then(function (confirmed) {
                            if (confirmed) {
                                temp.IsActive = target;
                                $http({
                                    method: 'Post',
                                    url: ApiUrl + '/api/Employee/SetStatus',
                                    data: temp
                                }).then(function successCallback(response) {
                                    $scope.grdEmployeeGrid.dataSource.read();
                                }, function errorCallback(response) {
                                    OnError(response);
                                });
                            }
                        });
                        return;
                    }
                }

                if ($scope.employee[KEY_NAME] == null) {
                    $scope.grdEmployeeGrid.dataSource.insert(0, response.data);
                }
                else {
                    var dataItem = $scope.grdEmployeeGrid.dataSource.get(response.data[KEY_NAME]);
                    for (var key in response.data) {
                        dataItem.set(key, response.data[key]);
                    }
                }

                $scope.employeeConfigwindow.close();
                $scope.employee[KEY_NAME] == null ? SetMessage("Save") : SetMessage("Update");
                $scope.employee.IsApplicationUser = false;
                $scope.isDisabled = false;
                $scope.grdEmployeeGrid.dataSource.read();
            }, function errorCallback(response) {
                OnError(response);
            });
        }
        else {
            $scope.isDisabled = false;
        }
    };

    $scope.cancel = function () {
        $scope.employeeConfigwindow.close();
    }

    $scope.goSearch = function () {
        $scope.grdEmployeeGrid.dataSource.page(1);
    }

    $scope.handleKeyPress = function (event) {
        if (event.keyCode == 13) {
            $scope.goSearch();
        }
    }

    $scope.clearSearch = function () {
        $scope.search = "";
        $scope.grdEmployeeGrid.dataSource.page(1);
    }

    $scope.onComboMaritalStatusChange = function (event) {
        var sender = event.sender;
        if (sender.value() && sender.selectedIndex == -1) {
            sender._filterSource({
                value: "",
                field: sender.options.dataTextField,
                operator: "contains"
            });
            sender.select(5);
        }
    }

    $scope.onComboGenderChange = function (event) {
        var sender = event.sender;
        if (sender.value() && sender.selectedIndex == -1) {
            sender._filterSource({
                value: "",
                field: sender.options.dataTextField,
                operator: "contains"
            });
            sender.select(0);
        }
    }

    hideloader();
}]);



