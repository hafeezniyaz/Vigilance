﻿app.controller("RoleController", ['$scope', '$http', '$rootScope', '$timeout', function ($scope, $http, $rootScope, $timeout) {
    $scope.search = "";
    $scope.roles = {};
    $scope.roles.UserRoleModel = {};
    var KEY_NAME = "RoleId";

    $rootScope.$on("LoadRolesTab", function () {
        if ($scope.grdRoleGrid.dataSource.data().length == 0) {
            $scope.grdRoleGrid.dataSource.read();
            $scope.cmbuser.dataSource.read();
        }
        if ($scope.grdRoleGrid.dataSource.data().length >= 0) {
            $scope.search = "";
            $scope.grdRoleGrid.dataSource.read();
            $scope.cmbuser.dataSource.read();
        }
    });
    $scope.getUserBuisnessUnits = function (id) {

        if (id != 0) {
            $http({
                method: 'get',
                asyc: false,
                url: ApiUrl + '/api/Role/GetUsersByRoleId?roleid=' + id
            }).then(function successCallback(response) {

                $scope.roles.UserRoleModel = response.data.length == 0 ? {} : response.data;
                $scope.cmbuser.value($scope.roles.UserRoleModel);
            }, function errorCallback(response) {

            });
        }
        else {
            $scope.UserRoleModel.value([]);
        }
    }
    $scope.popUp = function (e) {
        e.preventDefault();
        $("span.k-tooltip-validation").hide();
        var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
        $scope.roles = {};
        $scope.roles.UserRoleModel = {};


        $scope.winOptions = {
            title: dataItem == null ? "Add" : "Update",
        }
        if (dataItem != null) {
            $scope.roles = jQuery.extend({}, dataItem);
            $scope.getUserBuisnessUnits(dataItem[KEY_NAME]);

        }
        $scope.$apply();

        $scope.roleConfigwindow.setOptions($scope.winOptions);
        $scope.roleConfigwindow.open().center();
    };
    $scope.changeStatus = function (e) {
        e.preventDefault();
        var model = this.dataItem($(e.currentTarget).closest("tr"));
        var target = model.IsActive ? false : true;
        var warnText = target == false ? Constants.MSG_DEACTIVATE : Constants.MSG_ACTIVATE;
        $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
            if (confirmed) {
                model.IsActive = target;
                $http({
                    method: 'Post',
                    url: ApiUrl + '/api/Role/SetStatus',
                    data: model
                }).then(function successCallback(response) {
                    var index = findIndex($scope.grdRoleGrid.dataSource.data(), KEY_NAME, response.data[KEY_NAME]);
                    $scope.grdRoleGrid.dataSource.data()[index] = response.data;
                    $scope.grdRoleGrid.dataSource.sync();
                }, function errorCallback(response) {
                    OnError(response);
                });
            }
        });
    };

    $scope.grdRoleGridOptions = {
        dataSource: {
            transport: {
                read: {
                    type: "POST",
                    url: function () { return "/api/Role/Search" }
                },
                parameterMap: function (options, operation) {
                    var opt = {};
                    opt = options;
                    opt.search = $scope.search;
                    return opt;
                }
            },
            schema: {
                data: function (response) {
                    if (response && response.Result) {
                        return response.Result;
                    }
                    return [];
                },
                total: 'Total',
                model: {
                    id: KEY_NAME
                }
            },
            serverPaging: true,
            serverSorting: true,
            pageSize: 10
        },
        sortable: true,
        pageable: true,
        sortable: {
            allowUnsort: false
        },
        dataBound: OnRoleDataBound,
        columns: [
             { field: "Name", title: "{{'Role' | translate}}", width: "150px" },
             //{ field: "FirstNames", title: "{{'First Name' | translate}}", width: "200px" },
             { field: "UserNames", title: "{{'Users' | translate}}", width: "250px" },
             //{ field: "Description", title: "{{'Description' | translate}}", width: "360px" },
               //{ field: "isActive", title: "{{'Status'| translate}}", template: GetStatusTemplate,width:"100px" },
             {
                 command: [
                   { name: "editt", text: "<i class='k-icon k-edit'></i>", click: $scope.popUp },
                   //{ name: "deactivate", text: "<i class='k-icon k-delete'></i>", click: $scope.changeStatus },
                   //{ name: "activate", text: "<i class='k-icon k-i-undo'></i>", click: $scope.changeStatus }
                 ], title: "{{'Action'| translate}}", width: "100px", headerTemplate: '<label class="greenHeader">Action</label>'
             }
        ],
        toolbar: [{ name: "editt", text: "<i class='k-icon k-add'></i>{{'Add Role' | translate}}" }]
    }

    $scope.cmbuserOptions = {
        dataSource: {
            transport: {
                read: {
                    contentType: "application/json",
                    type: "Get",
                    url: function () {
                        return "/api/Employee/GetAll"
                    },
                    error: function (xhr, error) {
                        console.debug(xhr); console.debug(error);
                    }
                }
            },
            schema: {
                model: {
                    id: 'EmployeeID'
                }
            },
        },
        change: function (e) {
        },
        placeholder: "Select User...",
        dataTextField: "FirstName",
        dataValueField: "EmployeeID"
    };

    $scope.goSearch = function () {
        $scope.grdRoleGrid.dataSource.page(1);
    };
    $scope.clearSearch = function () {
        $scope.search = "";
        $scope.grdRoleGrid.dataSource.page(1);
    };
    $scope.handleKeyPress = function (keyEvent) {
        if (keyEvent.which === 13) {
            $scope.goSearch();
        }
    };
    $scope.cancel = function () {
        $scope.roleConfigwindow.close();
    };


    $scope.submit = function () {

        if ($scope.validator.validate()) {
            $("#formSubmit").attr('disabled', true);
            var model = $scope.roles;
            var names = "";
            var values = $scope.cmbuser.value();
            if (values != 0) {
                values.forEach(function (value) {
                    if (names == "") {
                        UserId = $scope.cmbuser.dataSource.get(value).UserNames;
                    } else {
                        names = names + ", " + $scope.cmbuser.dataSource.get(value).UserNames;
                    }
                });
            }
            if (names != "") {
                model.UserRoleModel[0].UserNames = names;
            }
            $http({
                method: 'Post',
                url: ApiUrl + ($scope.roles[KEY_NAME] == null ? '/api/Role/Add' : '/api/Role/update'),
                data: model
            }).then(function successCallback(response) {
                $("#formSubmit").attr('disabled', false);
                try {
                    // 
                    JSON.parse(response.data);
                }
                catch (e) {
                    // Role Name or User already exists
                    return WarnMessage(response.data);
                }

                if ($scope.roles[KEY_NAME] == null) {
                    $scope.grdRoleGrid.dataSource.insert(0, response.data);
                    $scope.goSearch();
                }
                else {
                    var index = findIndex($scope.grdRoleGrid.dataSource.data(), KEY_NAME, response.data[KEY_NAME]);
                    $scope.grdRoleGrid.dataSource.data()[index] = response.data;
                    $scope.grdRoleGrid.dataSource.sync();
                    $scope.goSearch();
                }
                $scope.roleConfigwindow.close();
                $scope.roles[KEY_NAME] == null ? SetMessage("Save") : SetMessage("Update");
            }, function errorCallback(response) {
                //SetMessage("Error")
                OnError(response);
            });
        }

    };

    function OnRoleDataBound() {
        var grid = this;
        var status = [Constants.Role.ROLE_RFS, Constants.Role.ROLE_AREAMANAGER, Constants.Role.ROLE_SUPERUSER, Constants.Role.ROLE_QUALITY_ADMIN, Constants.Role.ROLE_ASSESSOR]
        this.tbody.find("tr[role='row']").each(function () {
            var model = grid.dataItem(this);
            if (jQuery.inArray(model.RoleCode, status)) {
                $(this).find(".k-grid-activate").remove();
                $(this).find(".k-grid-deactivate").remove();
            }
            else if (model.IsActive) {
                $(this).find(".k-grid-activate").remove();
            } else {
                $(this).find(".k-grid-deactivate").remove();
            }
        });
    }
}]);
