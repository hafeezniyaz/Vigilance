﻿app.controller("UserController", ['$scope', '$http', '$rootScope', function ($scope, $http, $rootScope) {
    var KEY_NAME = "UserId";
    $scope.search = "";
    $scope.BuData = [];
    $scope.Related = [];
    $scope.user = {};
    $scope.user.UserBuisnessUnitMapModel = {};
    $scope.AdUserList = {};
    $scope.CallRoles = function () {
        //  $rootScope.$emit("ReloadRoles", {});
    $scope.cmbRole.dataSource.read();
    }
    $rootScope.$on("LoadUserTab", function () {
        if ($scope.grdUserGrid.dataSource.data().length == 0) {
            $scope.search = "";
            $scope.user = {};
            var KEY_NAME = "UserId";
            $scope.grdUserGrid.dataSource.read();
        }
        if ($scope.grdUserGrid.dataSource.data().length >= 0) {
            $scope.search = "";
            //$scope.cmbRole.dataSource.read();
            $scope.grdUserGrid.dataSource.read();
        }
    });

      $scope.popUp = function (e) {
        e.preventDefault();
        $scope.userAddConfigwindow.close();
        $("span.k-tooltip-validation").hide();

        var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
        $scope.user = {
        };
        $scope.user.UserBuisnessUnitMapModel = {};

        if (dataItem != null) {
          //  $scope.cmbRole.value(dataItem.RoleId);
            $scope.user = jQuery.extend({}, dataItem);
         //   $scope.user.UserBuisnessUnitMapModel = {};

        }
        else {
           // $scope.cmbRole.value("");
            $scope.addPopup();
            return;
        }
        //if ($scope.cmbRole.dataSource.data().length == 0) {
        //    $scope.cmbRole.dataSource.read();
        //}
        $scope.$apply();
      //  $scope.getUserBuisnessUnits(dataItem[KEY_NAME]);
        $scope.winOptions = {
            title: dataItem[KEY_NAME] == 0 ? "Add" : "Update",
        }
        $scope.userConfigwindow.setOptions($scope.winOptions);
        $scope.userConfigwindow.open().center();
    };

    $scope.addPopup = function () {
        $scope.clearAdSearch();
        $scope.userAddConfigwindow.center().open();

    };

    $scope.changeStatus = function (e) {
        e.preventDefault();
        var model = this.dataItem($(e.currentTarget).closest("tr"));
        model = jQuery.extend({
        }, model);
        var target = model.IsActive ? false : true;
        var warnText = target == false ? Constants.MSG_DEACTIVATE : Constants.MSG_ACTIVATE;
        $.when(showConfirmationWindow(warnText)).then(function (confirmed) {
            if (confirmed) {
                model.IsActive = target;
                $http({
                    method: 'Post',
                    url: ApiUrl + '/api/User/SetStatus',
                    data: model
                }).then(function successCallback(response) {
                    if (response != null && response.data == "CantDeactivate") {
                        Error(" Cannot deactivate as " + model.FullName + " exists in mapping/assignment(s)/delegation ");
                        return;
                    }
                    if (response != null && response.data == "BusinessUnit") {
                        Error(" Cannot deactivate as " + model.FullName + " exists in mapping/assignment(s)/delegation ");
                        return;
                    }
                    $scope.grdUserGrid.dataSource.read();
                }, function errorCallback(response) {
                    OnError(response);
                });
            }
        });
    };
    $scope.grdAdUserOption = {
        dataSource: {
            transport: {
                read: {
                    type: "POST",
                    url: function () {
                        return "/api/User/GetActiveADUserList"
                    },
                    complete: function (response) {
                        $(".k-loading-mask").hide();
                    },
                    error: function (data) {
                        $(".k-loading-mask").hide();
                    }
                },
                parameterMap: function (options, operation) {
                    var opt = {
                    };
                    opt = options;
                    opt.search = $scope.adSearch;
                    return options;
                }
            },
            schema: {
                data: function (response) {
                    if (response && response.Result) {
                        return response.Result;
                    }
                    return [];
                },
                total: 'Total',
                model: {
                    id: 'ADId'
                }
            },
            serverPaging: true,
            serverSorting: true,
            pageSize: 10
        },
        pageable: true,
        sortable: {
            allowUnsort: false
        },
        dataBound: function () {
            var grid = this;
            this.tbody.find("tr[role='row']").each(function () {
                var model = grid.dataItem(this);
                if (model.onAD == 1) {
                    $(this).find(".k-grid-editt").parent('td').empty().html('<span class="glyphicon glyphicon-ok glyp-ok" style="padding-left:20px"></span>');
                }
            });
        },
        columns: [
{
    field: "FullName", title: "{{'Name' | translate}}"
},
{
    field: "UserName", title: "{{'Username' | translate}}"
},
{
    field: "Email", title: "{{'Email' | translate}}", width: 300
},
{
    command: [
{
    name: "editt", text: "<i class='k-icon k-add'></i>", click: $scope.popUp
}
    ], title: "{{'Action' | translate}}", width: 70
}]

    };



    $scope.grdUserGridOptions = {
        dataSource: {
            transport: {
                read: {
                    type: "POST",
                    url: function () {
                        return "/api/User/Search"
                    },
                    complete: function (response) {
                        hideloader();
                    }
                },
                parameterMap: function (options, operation) {
                    var opt = {
                    };
                    opt = options;
                    opt.search = $scope.search;
                    return opt;
                }
            },
            schema: {
                data: function (response) {
                    if (response && response.Result) {
                        return response.Result;
                    }
                    return [];
                },
                total: 'Total',
                model: {
                    id: KEY_NAME
                }
            },
            serverPaging: true,
            serverSorting: true,
            pageSize: 10
        },
        pageable: true,
        sortable: {
            allowUnsort: false
        },
        dataBound: OnKendoDataBound,
        columns: [
         { field: "FullName", title: "{{'Name' | translate}}" },
         { field: "UserName", title: "{{'Username' | translate}}"},
         { field: "Email", title: "{{'Email' | translate}}", width: 350 },
       //{ field: "UserRoleName", title: "{{'Role' | translate}}", width: 180,hidden :true},
       //{ field: "UserBuisnessUnitName", title: "{{'Business Unit' | translate}}", width: 260, hidden :true},
         { field: "IsActive", title: "{{'Status' | translate}}", template: GetStatusTemplate },
         {
              command: [
            { name: "editt", text: "<i class='k-icon k-edit'></i>", click: $scope.popUp},
            { name: "deactivate", text: "<i class='k-icon k-delete'></i>", click: $scope.changeStatus },
            { name: "activate", text: "<i class='k-icon k-i-undo'></i>", click: $scope.changeStatus }
                       ], title: "{{'Action' | translate}}"}
            ],

        editable: "popup",
        toolbar: [{
            name: "editt", text: "<i class='k-icon k-add'></i>{{'Add User' | translate}}"
        }]
    }

    $scope.goSearch = function () {
        $scope.grdUserGrid.dataSource.page(1);
    };
    $scope.clearSearch = function () {
        $scope.search = "";
        $scope.grdUserGrid.dataSource.page(1);
    };
    $scope.handleKeyPress = function (keyEvent) {
        if (keyEvent.which === 13) {
            $scope.goSearch();
        }
    };

    $scope.goAdSearch = function () {
        $scope.grdAdUserGrid.dataSource.page(1);
    };
    $scope.clearAdSearch = function () {
        $scope.adSearch = "";
        $scope.goAdSearch();
    };
    $scope.handleAdKeyPress = function (keyEvent) {
        if (keyEvent.which === 13) {
            $scope.goAdSearch();
        }
    };
    $scope.cancel = function () {
        $scope.userConfigwindow.close();
    };
    $scope.submit = function () {
        if ($scope.validator.validate()) {
            var names = ""; 
            var model = jQuery.extend({}, $scope.user);
            $http({
                method: 'Post',
                url: ApiUrl + ($scope.user[KEY_NAME] == 0 ? '/api/User/Add' : '/api/User/update'),
                data: model
            }).then(function successCallback(response) {

                if (response != null && response.data == "UserNameExist") {
                    WarnMessage("Username " + model.UserName + " already exists!");
                    return;
                }

                if (response != null && response.data == "EmailExist") {
                    WarnMessage("Email Id " + model.Email + " already exists!");
                    return;
                }

                if (response != null && response.data == "exist") {
                    WarnMessage("User " + model.FullName + " already exists!");
                    return;
                }

                if (response != null && response.data == "Mapped") {
                    Error(" Cannot edit as " + model.FullName + " exists in mapping/assignment(s)/delegation ");
                    return;
                }
                if (response != null && response.data == "Role") {
                    WarnMessage("Role cannot be changed as " + model.FullName + " is an assessor in active assessment(s)");
                    return;
                }
                if (response != null && response.data == "BusinessUnit") {
                    Error(" Cannot edit as " + model.FullName + " exists in mapping/assignment(s)/delegation ");
                    return;
                }
                if (response != null && response.data == "MainManager") {
                    WarnMessage("Business unit cannot be changed as " + model.FullName + " is already a MainManager");
                    return;
                }
                $scope.grdUserGrid.dataSource.read();

                $scope.userConfigwindow.close();
                $scope.user[KEY_NAME] == 0 ? SetMessage("Save") : SetMessage("Update");

            }
                    , function errorCallback(response) {
                        //SetMessage("Error");
                        OnError(response);
                    });
        }

    };

    $scope.onComboChange = function (e) {
        var sender = e.sender;
        if (sender.value() && sender.selectedIndex == -1) {
            sender._filterSource({
                value: "",
                field: sender.options.dataTextField,
                operator: "contains"
            });
            sender.select(0);
        }
    };
}]);

Array.prototype.where = Array.prototype.filter || function (predicate, context) {
    context = context || window;
    var arr = [];
    var l = this.length;
    for (var i = 0; i < l; i++)
        if (predicate.call(context, this[i], i, this) === true) arr.push(this[i]);
    return arr;
};
function Error(message) {
    $("#App_CloseAlert").show();
    $("#App_AlertHead").text("Error")
    $("#App_AlertText").text(message);
    setTimeout(function () {
        $("#App_Alert").fadeIn(280);
    }, 100);
}