﻿

app.controller("ManageController", ['$scope', '$http', '$rootScope', function ($scope, $http, $rootScope) {
 
    //$rootScope.$emit("LoadEmployeeTab", {});
    $scope.LoadEmployeeTab = function () {
        $rootScope.$emit("LoadEmployeeTab", {});
    };
    $scope.LoadRolesTab = function () {
        $rootScope.$emit("LoadRolesTab", {});
    };

    $scope.LoadPermissionTab = function () {
        $rootScope.$emit("LoadPermissionTab", {});
    };
    hideloader();
}]);

$(document).ready(function () {
    debugger
    var ts = $("#tabstrip").kendoTabStrip({
        animation: { open: { effects: "fadeIn" } }
    }).data('kendoTabStrip');
});