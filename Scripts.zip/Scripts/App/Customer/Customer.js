﻿app.controller("CustomerController", ['$scope', '$http', '$rootScope', function ($scope, $http, $rootScope) {
    $scope.search = "";
    var KEY_NAME = "EmployeeID";
    Schema = "Employee";
    $scope.isDisabled = false;
  

      // GET THE FILE INFORMATION.
        $scope.getFileDetails = function (e) {
            debugger;
            $scope.files = [];
            $scope.$apply(function () {

                // STORE THE FILE OBJECT IN AN ARRAY.
                for (var i = 0; i < e.files.length; i++) {
                    $scope.files.push(e.files[i])
                }

            });
        };

    // NOW UPLOAD THE FILES.
        $scope.uploadFiles = function () {
            debugger;
            showloader();
            //FILL FormData WITH FILE DETAILS.
            var data = new FormData();

            for (var i in $scope.files) {
                data.append("uploadedFile", $scope.files[i]);
            }

            // ADD LISTENERS.
            var objXhr = new XMLHttpRequest();

            objXhr.onreadystatechange = function () {
                debugger
               // var res =  XMLHttpRequest.responseText;

                if (this.readyState == 4 && this.status == 200) {
                    hideloader();

                    if(objXhr.responseText == "true")       
                    CustomMessage("Saved","Excel uploaded successfully.");
                    else
                    WarnMessage("Excel upload failed !!");
                   
                }
            };

            // SEND FILE DETAILS TO THE API.
            objXhr.open("POST", ApiUrl + '/api/CustomerDetails/FileUpload');
            objXhr.send(data);
        }

   

    // CONFIRMATION.
        function transferComplete(e) {
            CustomMessage("Uploaded", "Files uploaded successfully.");
        }

  
    $scope.submitUpload = function (e)
    {
        e.files.length;
        debugger;
       // $scope.SelectedFiles = files;
        if($scope.SelectedFiles && $scope.SelectedFiles.length) {
            $http(
                    {
                        method: 'POST',
                        url: ApiUrl + '/api/CustomerDetails/UploadExcel',
                        data: {
                            FileUpload: $scope.SelectedFiles
                        },
                    }).then(function successCallback(response) {
                         debugger
                        if (response == "")
                        {

                        }
                       

                        hideloader();
                        CustomMessage("Uploaded", "Excel uploaded");
                    }).then(function errorCallback(response) {
                        hideloader();
                        WarnMessage("Excel upload failed !!");
                    })
        }
    };


    $scope.delete = function (e) {
        e.preventDefault();
        var model = this.dataItem($(e.currentTarget).closest("tr"));
        var warnText = Constants.MSG_DELETE;
        $.when(showConfirmationWindow(warnText)).then(function (confirm) {
            if (confirm) {

                $http({
                    method: "Post",
                    url: ApiUrl + "/api/Employee/Delete",
                    data: model
                }).then(function successCallback(response) {
                    console.log("For Delete" + response);
                    $scope.grdEmployeeGrid.refresh();
                    SetMessage("Delete");
                    $scope.grdEmployeeGrid.dataSource.read();
                },
                function errorCallback(response) {
                    OnError(response);
                });
            }
        });
    }


    hideloader();
}]);



