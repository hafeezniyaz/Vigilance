﻿var Schema = "";
var AuditFlag = false;
var dateUSFormat = 'MM/dd/yyyy';

function SetMessage(type) {
    $("#App_CloseAlert").hide();
    if (type == "Save") {
        $("#App_AlertHead").text("Success")
        $("#App_AlertText").text("Details Saved Successfully");
    }

    else if (type == "Update") {
        $("#App_AlertHead").text("Success")
        $("#App_AlertText").text("Details Updated Successfully");
    }
    else if (type == "Delete") {
        $("#App_AlertHead").text("Success")
        $("#App_AlertText").text("Details Deleted Successfully");

    }
    else if (type == "Discard") {
        $("#App_AlertHead").text("Success")
        $("#App_AlertText").text("Review Discarded Successfully");
    }
    else if (type == "Assign") {
        $("#App_AlertHead").text("Success")
        $("#App_AlertText").text("User Assigned Successfully");
    }
    else if (type == "NotAssign") {
        $("#App_AlertHead").text("Warning")
        $("#App_AlertText").text("User Is Not Assigned");
    }
    else if (type == "DiscardRandomizedCase") {
        $("#App_AlertHead").text("Success")
        $("#App_AlertText").text("Case Discarded Successfully");
    }
    else if (type == "Flag") {
        $("#App_AlertHead").text("Success")
        $("#App_AlertText").text("Review Flagged Successfully!");
    }
    else if (type == "UnFlag") {
        $("#App_AlertHead").text("Success")
        $("#App_AlertText").text("Review Unflagged Successfully!");
    }
    else if (type == "Exist") {
        $("#App_AlertHead").text("Warning")
        $("#App_AlertText").text("This Record Already Exists");
    }
    else if (type == "NotificationDays") {
        $("#App_AlertHead").text("Warning")
        $("#App_AlertText").text("Notification Day/s cannot be greater than 28 or less than 1");
    }
    else if (type == "CantDelete") {
        $("#App_AlertHead").text("Warning")
        $("#App_AlertText").text("Can't Delete this Record");
    }
    else if (type == "Error") {
        $("#App_AlertHead").text("Error")
        $("#App_AlertText").text("Error Occured While Processing Your Request");
    }
    else if (type == "emailAttachment") {
        $("#App_AlertHead").text("Success")
        $("#App_AlertText").text("Email sent successfully");
    }

    setTimeout(function () {
        $("#App_Alert").fadeIn(280);
    }, 100);
    setTimeout(function () {
        $("#App_Alert").fadeOut(400);
    }, 2000)
}
function CustomMessage(type, message) {
    $("#App_CloseAlert").hide();
    $("#App_AlertHead").text(type)
    $("#App_AlertText").text(message);
    setTimeout(function () {
        $("#App_Alert").fadeIn(280);
    }, 200);
    setTimeout(function () {
        $("#App_Alert").fadeOut(400);
    }, 2000)
}

function CustomWindow(message, title) {
    var dfd = new jQuery.Deferred();
    var result = false;
    $("<div id='popupWindow'></div>")
    .appendTo("body")
    .kendoWindow({
        width: "400px",
        modal: true,
        title: title,
        modal: true,
        visible: false,
        close: function (e) {
            this.destroy();
            dfd.resolve(result);
        },
        actions: {}
    }).data('kendoWindow').content($('#confirmationTemplate').html()).center().open();
    $('.popupMessage').html(message);
    $('#popupWindow .confirm_yes').val('OK');
    $('#popupWindow .confirm_no').hide();
    $('#popupWindow .confirm_yes').click(function () {
        result = true;
        $('#popupWindow').data('kendoWindow').close();
    });
    return dfd.promise();
}


function WarnMessage(message) {
    $("#App_CloseAlert").show();
    $("#App_AlertHead").text("Warning")
    $("#App_AlertText").text(message);
    setTimeout(function () {
        $("#App_Alert").fadeIn(280);
    }, 100);
}

function RandamizeMessage(type, message) {
    $("#App_CloseAlert").show();
    $("#App_AlertHead").text(type)
    $("#App_AlertText").text(message);
    setTimeout(function () {
        $("#App_Alert").fadeIn(280);
    }, 100);
}

function App_CloseAlert() {
    $("#App_Alert").fadeOut(200);
}

$(document).ready(function () {

    //Advanceed search script
    $(".search-toggle").click(function () {
        $(".dropdown-search").toggleClass("showdiv");
        $("div#search-overlay").toggleClass("showdiv");
        $("body").toggleClass("search-active");
        $(".dropdown-search").css({ "display": "" });
        return false;
    });
    $("#search-overlay").click(function () {
        $(".dropdown-search").toggleClass("showdiv");
        $("body").toggleClass("search-active");
        $("#search-overlay").toggleClass("showdiv");

    });

    $(document).on("keypress", ".text", function (event) {
        var regex = new RegExp("^[a-zA-Z ]+$");
        var key = String.fromCharCode(!event.charCode ? event.which : event.charCode);
        if (!regex.test(key) && event.which != 0 && event.which != 8) {
            event.preventDefault();
            return false;
        }
    });

    $(document).on("keypress", ".number", function (event) {
        var inputValue = event.which;
        if ((inputValue == 46 && inputValue > 31) && (inputValue < 48 || inputValue > 57)) {
            event.preventDefault();
        }

    });
});

// Advanceed search
function SearchBoxToggleClass() {
    $(".dropdown-search").toggleClass("showdiv");
    $("#search-overlay").toggleClass("showdiv");
    $("body").toggleClass("search-active");
}

function SearchBoxRemoveClass() {
    $(".dropdown-search").removeClass("showdiv");
    $("#search-overlay").removeClass("showdiv");
    $("body").removeClass("search-active");
}

function HideAudit() {
    $("#AuditWindow").removeClass('nav-view');
    $("body").removeClass('no-scroll');
    //setTimeout(function () {
    //    $("#AuditWindow").toggleClass('nav-view');
    //}, 300);
    $("#AuditOverlay").hide();

}

function GetAudit(target, id) {
    AuditFlag = true;
    $.ajax({
        contentType: "application/json",
        type: "Post",
        url: "/api/AuditTrial/Get?lookup=" + target + "&id=" + id,
        success: function (result) {
            $("#AuditWindow").toggleClass('nav-view');
            $("body").toggleClass('no-scroll');
            // $("#AuditWindow").animate({ transform: 'scale(1,1)' });
            $("#AuditOverlay").show();

            ShowAudit(result);
            AuditFlag = false;
        },
        error: function (data) {

        }
    });
}

function ShowAudit(data) {
    var html = ""; // "<tr><th>#</th><th>Action</th><th>Done By</th><th>Done At</th></tr>";
    if (data.length > 0) {
        for (var i = 0; i < data.length; i++) {
            html += "<tr><td><div class='AuditMileStone'></div></td><td colspan='3'><b>" + data[i].Action + "</b> By <b>" + data[i].FullName + "</b> on <b>" + data[i].StrActionDate + "</b></td></tr>";
            if (data[i].ChangeList != null) {
                for (var k = 0; k < data[i].ChangeList.length; k++) {
                    html += "<tr><td>&nbsp;</td><td colspan='3' style='padding-left:20px;'><span style='color:blue'>" + data[i].ChangeList[k].Property + "</span> Updated <span style='color:green'>" + data[i].ChangeList[k].ChangeDetail + "</span></td></tr>";
                }
            }
        }
    }
    else
        html += "<tr><td colspan='4' style='text-align:center'>No History to show</tr>";
    $("#AuditData").html(html);

}

function ReadCookie(cname) {
    var re = new RegExp(cname + "=([^;]+)");
    var value = re.exec(document.cookie);
    return (value != null) ? unescape(value[1]) : null;
}

$('form').kendoValidator({
    errorTemplate: "<span  class='k-widget k-tooltip k-tooltip-validation' translate>#=message#</span>",
    rules: {
        required: function (input) {

            if (input.filter("[required]").length && $.trim(input.val()) == "") {
                input.val('');
                return false;
            }
            return true;
        },

    },
    messages: {
        required: "This field is required",
    }
});
function showWindow(message) {
    var dfd = new jQuery.Deferred();
    var result = false;
    $("<div id='popupWindow'></div>")
    .appendTo("body")
    .kendoWindow({
        width: "400px",
        modal: true,
        title: "",
        modal: true,
        visible: false,
        close: function (e) {
            this.destroy();
            dfd.resolve(result);
        },
        actions: {}
    }).data('kendoWindow').content($('#confirmationTemplate').html()).center().open();
    $('.popupMessage').html(message);
    $('#popupWindow .confirm_yes').val('OK');
    $('#popupWindow .confirm_no').hide();
    $('#popupWindow .confirm_yes').click(function () {
        result = true;
        $('#popupWindow').data('kendoWindow').close();
    });
    return dfd.promise();
};

function showConfirmationWindow(message) {

    var dfd = new jQuery.Deferred();
    var result = false;

    $("<div id='popupWindow'></div>")
    .appendTo("body")
    .kendoWindow({
        width: "400px",
        modal: true,
        title: "Confirmation",
        modal: true,
        visible: false,
        close: function (e) {
            this.destroy();
            dfd.resolve(result);
        }
    }).data('kendoWindow').content($('#confirmationTemplate').html()).center().open();

    $('.popupMessage').html(message);

    $('#popupWindow .confirm_yes').val('OK');
    $('#popupWindow .confirm_no').val('Cancel');

    $('#popupWindow .confirm_no').click(function () {
        $('#popupWindow').data('kendoWindow').close();
    });

    $('#popupWindow .confirm_yes').click(function () {
        result = true;
        $('#popupWindow').data('kendoWindow').close();
    });

    return dfd.promise();
};

function showConfirmationActiveWindow(message) {

    var dfd = new jQuery.Deferred();
    var result = false;

    $("<div id='popupWindow'></div>")
    .appendTo("body")
    .kendoWindow({
        width: "400px",
        modal: true,
        title: "Confirmation",
        modal: true,
        visible: false,
        close: function (e) {
            this.destroy();
            dfd.resolve(result);
        }
    }).data('kendoWindow').content($('#confirmationTemplate').html()).center().open();

    $('.popupMessage').html(message);

    $('#popupWindow .confirm_yes').val('Yes');
    $('#popupWindow .confirm_no').val('No');

    $('#popupWindow .confirm_no').click(function () {
        $('#popupWindow').data('kendoWindow').close();
    });

    $('#popupWindow .confirm_yes').click(function () {
        result = true;
        $('#popupWindow').data('kendoWindow').close();
    });

    return dfd.promise();
};

function showPromptWindow(message, defaultText) {

    var dfd = new jQuery.Deferred();
    var result = null;

    $("<div id='promptWindow'></div>")
    .appendTo("body")
    .kendoWindow({
        width: "400px",
        modal: true,
        title: "Confirmation",
        modal: true,
        visible: false,
        close: function (e) {
            this.destroy();
            dfd.resolve(result);
        }
    }).data('kendoWindow').content($('#promptTemplate').html()).center().open();

    $('#promptPopupMessage').html(message);
    $('#promptTxt').val(defaultText);

    $('#promptWindow .confirm_yes').val('OK');
    $('#promptWindow .confirm_no').val('Cancel');

    $('#promptWindow .confirm_no').click(function () {
        $('#promptWindow').data('kendoWindow').close();
    });

    $('#promptWindow .confirm_yes').click(function () {
        result = $('#promptTxt').val();
        $('#promptWindow').data('kendoWindow').close();
    });

    return dfd.promise();
};

function GetStatusTemplate(item) {
    var txt = item.IsActive ? "Active" : "Inactive";
    return "<span class='" + (item.IsActive ? 'Yes' : 'No') + "'>" + txt + "</span>";
};

function StatusCheck(item) {
    var str;
    str = item.Status;

    if (str == null || str == Constants.StatusType.Scheduled) {
        return "<span style='color:#0707cc;'>" + Constants.StatusType.Scheduled + "</span>";
    }
    if (str == Constants.StatusType.Assessed) {
        return "<span style='color:#f39c12'> Assessed </span>";
    }
    if (str == Constants.StatusType.RFSReviewed) {
        return "<span style='color:#ec09ec'>  Reviewed </span>";
    }
    if (str == Constants.StatusType.RFSReSubmitted) {
        return "<span style='color:#ec09ec'>  ReSubmitted </span>";
    }
    if (str == Constants.StatusType.Complete) {
        return "<span style='color:green'> Completed </span>";
    }
    if (str == Constants.StatusType.AreaManagerRejected) {
        return "<span style='color:orange'> Rejected </span>";
    }
    if (str == Constants.StatusType.Escalated) {
        return "<span style='color:red'>" + Constants.StatusType.Escalated + "</span>";
    }
    if (str == Constants.StatusType.RejectedEscalation) {
        return "<span style='color:orange'>" + Constants.StatusType.RejectedEscalation + "</span>";
    }
    if (str == Constants.StatusType.Rescheduled) {
        return "<span style='color:#ec09ec'>" + Constants.StatusType.Rescheduled + "</span>";
    }
    if (str == Constants.StatusType.Closed) {
        return "<span style='color:orange'>" + Constants.StatusType.Closed + "</span>";
    }
    if (str == Constants.StatusType.Draft) {
        return "<span style='color:#ec09ec'>" + Constants.StatusType.Draft + "</span>";
    }
}
function result(item) {
    var str;
    str = item.Result;
    if (str.toLowerCase().trim() == 'pass') {
        return "<span class='resultPass'>" + 'Pass' + "</span>"
    }
    if (str.toLowerCase().trim() == 'fail') {
        return "<span class='resultFail'>" + 'Fail' + "</span>"
    }
}
function findIndex(arraytosearch, key, valuetosearch) {
    for (var i = 0; i < arraytosearch.length; i++) {
        if (arraytosearch[i][key] == valuetosearch) {
            return i;
        }
    }
    return null;
}

function hideloader() {
    $('#LoadingImg').hide();
   // $(".content").show();
}
function showloader() {
    $('#LoadingImg').show();

}
function OnKendoDataBound() {
    var grid = this;
    this.tbody.find("tr[role='row']").each(function () {
        var model = grid.dataItem(this);
        //if (model.Isexists != 0) {
        //    $(this).css({ "background-color": "silver" });
        //    $(this).find(".k-grid-editt").prop('disabled', true);
        //    $(this).find(".k-grid-deletee").prop('disabled', true);
        //}
        if (model.IsActive) {
            $(this).find(".k-grid-activate").remove();
        } else {
            $(this).find(".k-grid-deactivate").remove();
        }
    });

    if (this.dataSource.view().length == 0) {
        var currentPage = this.dataSource.page();
        if (currentPage > 1) {
            this.dataSource.page(currentPage - 1);
        }
    }
}
function GetInactveTemplate(item) {
    if (item.IsActive) {
        return item.Name;
    }
    return "<span class='inactive'>" + item.Name + " (Inactive)<span>";
}
function getParameterByName(name) {
    var url = window.location;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function OnError(response) {
    window.location.href = "/HOME/ERROR?ExceptionType=" + response.data.ExceptionType;
}

//To append the parameter(s) to the URL
function URL_add_parameter(url, param, value) {
    var hash = {};
    var parser = document.createElement('a');

    parser.href = url;

    var parameters = parser.search.split(/\?|&/);

    for (var i = 0; i < parameters.length; i++) {
        if (!parameters[i])
            continue;

        var ary = parameters[i].split('=');
        hash[ary[0]] = ary[1];
    }

    hash[param] = value;

    var list = [];
    Object.keys(hash).forEach(function (key) {
        list.push(key + '=' + hash[key]);
    });

    parser.search = '?' + list.join('&');
    return parser.href;
}

// for Pie High chart
// InnerSize = 0
// Depth = 0

// for Donut High chart
// InnerSize = 100
// Depth = 45
function getPieDonutHighChart(controlId, chartType, dataToDisplay, InnerSize, Depth, onClick) {
    Highcharts.chart(controlId, {
        chart: {
            type: chartType,
            options3d: {
                enabled: true,
                alpha: 45,
                beta: 0,
            }
        },
        title: {
            text: ''
        },
        tooltip: {
            //pointFormat: '{series.name}: <b>{point.percentage:.1f}%</b>'
        },
        plotOptions: {
            pie: {
                innerSize: InnerSize,
                depth: Depth,
                allowPointSelect: true,
                cursor: 'pointer',
                depth: 35,
                dataLabels: {
                    enabled: true,
                    format: '{point.name}'
                }
            }
        },
        credits: {
            enabled: false
        },
        exporting: { enabled: false },
        series: [{
            type: chartType,
            data: dataToDisplay,
            showInLegend: false,
            name: ' ',
            cursor: 'pointer',
            point: {
                events: {
                    click: function (event) {
                        window.location = onClick
                    }
                }
            }
        }]
    });
}

function getColumnHighChart(controlId, chartType, xAxisData, seriesData) {
    var chart = new Highcharts.Chart({
        chart: {
            renderTo: controlId,
            type: chartType,
            options3d: {
                enabled: true,
                alpha: 15,
                beta: 15,
                depth: 50,
                viewDistance: 25
            }
        },
        title: {
            text: ''
        },
        xAxis: {
            categories: xAxisData
        },
        subtitle: {
            text: ''
        },
        plotOptions: {
            column: {
                depth: 25
            }
        },
        credits: {
            enabled: false
        },
        exporting: { enabled: false },
        plotOptions: {
            series: {
                cursor: 'pointer',
                events: {
                    click: function (event) {
                        window.location = '/QualityControlCaseReview/AllReview'
                    }
                }
            }
        },
        series:
            [{
                data: seriesData,
                showInLegend: false,
                name: ' '
            }]
    });
    return chart;
}
function getLineChart(controlId, chartType, xAxisData, seriesData, chartTitle, seriesName, _colorList) {
    //var _colorList = ["#48D1CC", "#f44455", "#6cc788", "#6887ff", "#fcc100", "#f77a99", "#a88add", "#0cc2aa", "#2196f3", "#8bc34a", "#B0171F", "#DB7093", "#DC143C", "#FFAEB9", "#8B475D", "#FF3E96", "#FF1493", "#CD1076", "#9400D3", "#0000FF", "#8B8B00", "#00008B", "#6495ED", "#00BFFF", "#00F5FF", "#00FA9A", "#008B45", "#EEEE00", "#EE4000", "#8E388E", "#8E8E38", "#C67171"];
    $("#" + controlId).kendoChart({
        title: {
            text: chartTitle
        },
        legend: {
            position: "bottom",
            visible: true
        },
        seriesDefaults: {
            type: chartType,
            labels: {
                visible: true,
                template: "#= value #%",
                background: "transparent",
                position: "outsideEnd"
            }
        },
        valueAxis: {
            labels: {
                format: "{0}%"
            },
            line: {
                visible: false
            },
            axisCrossingValue: 0
        },
        series: [{
            data: seriesData,
            //name: 'CalFresh',
            showInLegend: false,
        }],
        categoryAxis: {
            categories: xAxisData,
            labels: {
                rotation: -20,
            }
        },
        seriesColors: _colorList,
        tooltip: {
            visible: true,
            position: "top",
            template: "#= category # : #= value #%"
        }
    });
}
function getLineChartWithoutPercentage(controlId, chartType, xAxisData, seriesData, chartTitle, _colorList) {
    //var _colorList = ["#48D1CC", "#f44455", "#6cc788", "#6887ff", "#fcc100", "#f77a99", "#a88add", "#0cc2aa", "#2196f3", "#8bc34a", "#B0171F", "#DB7093", "#DC143C", "#FFAEB9", "#8B475D", "#FF3E96", "#FF1493", "#CD1076", "#9400D3", "#0000FF", "#8B8B00", "#00008B", "#6495ED", "#00BFFF", "#00F5FF", "#00FA9A", "#008B45", "#EEEE00", "#EE4000", "#8E388E", "#8E8E38", "#C67171"];
    $("#" + controlId).kendoChart({
        title: {
            text: chartTitle
        },
        legend: {
            position: "bottom",
            visible: true
        },
        seriesDefaults: {
            type: chartType,
            labels: {
                visible: true,
                template: "#= value #",
                background: "transparent",
                position: "outsideEnd"
            }
        },
        valueAxis: {
            labels: {
                format: "{0}"
            },
            line: {
                visible: false
            },
            axisCrossingValue: 0
        },
        series: [{
            data: seriesData,
            //name: 'CalFresh',
            showInLegend: false,
        }],
        categoryAxis: {
            categories: xAxisData,
            labels: {
                rotation: -20,
            }
        },
        tooltip: {
            visible: true,
            position: "top",
            template: "#= category # : #= value #"
        },
        seriesColors: _colorList
    });
}
function getLineChartForMultipleYAxis(controlId, chartType, xAxisData, seriesData, chartTitle, seriesName, _colorList) {
    //var _colorList = ["#48D1CC", "#f44455", "#6cc788", "#6887ff", "#fcc100", "#f77a99", "#a88add", "#0cc2aa", "#2196f3", "#8bc34a", "#B0171F", "#DB7093", "#DC143C", "#FFAEB9", "#8B475D", "#FF3E96", "#FF1493", "#CD1076", "#9400D3", "#0000FF", "#8B8B00", "#00008B", "#6495ED", "#00BFFF", "#00F5FF", "#00FA9A", "#008B45", "#EEEE00", "#EE4000", "#8E388E", "#8E8E38", "#C67171"];
    $("#" + controlId).kendoChart({
        title: {
            text: chartTitle
        },
        legend: {
            position: "bottom",
            visible: true
        },
        seriesDefaults: {
            type: chartType,
            labels: {
                visible: true,
                template: "#= value #%",
                background: "transparent",
                position: "outsideEnd"
            }
        },
        valueAxis: {
            labels: {
                format: "{0}%"
            },
            line: {
                visible: false
            },
            axisCrossingValue: 0
        },
        series: seriesData,
        categoryAxis: {
            categories: xAxisData,
            labels: {
                rotation: -20,
            }
        },
        tooltip: {
            visible: true,
            position: "top",
            template: "#= series.name #: #= value #%"
        },
        seriesColors: _colorList
    });
}
function getLineChartForMultipleYAxisWithoutPercentage(controlId, chartType, xAxisData, seriesData, chartTitle, seriesName, _colorList) {
    //var _colorList = ["#48D1CC", "#f44455", "#6cc788", "#6887ff", "#fcc100", "#f77a99", "#a88add", "#0cc2aa", "#2196f3", "#8bc34a", "#B0171F", "#DB7093", "#DC143C", "#FFAEB9", "#8B475D", "#FF3E96", "#FF1493", "#CD1076", "#9400D3", "#0000FF", "#8B8B00", "#00008B", "#6495ED", "#00BFFF", "#00F5FF", "#00FA9A", "#008B45", "#EEEE00", "#EE4000", "#8E388E", "#8E8E38", "#C67171"];
    $("#" + controlId).kendoChart({
        title: {
            text: chartTitle
        },
        legend: {
            position: "bottom",
            visible: true
        },
        seriesDefaults: {
            type: chartType,
            labels: {
                visible: true,
                template: "#= value #",
                background: "transparent",
                position: "outsideEnd"
            }
        },
        valueAxis: {
            labels: {
                format: "{0}"
            },
            line: {
                visible: false
            },
            axisCrossingValue: 0
        },
        series: seriesData,
        categoryAxis: {
            categories: xAxisData,
            labels: {
                rotation: -20,
            }
        },
        tooltip: {
            visible: true,
            position: "top",
            template: "#= series.name #: #= value #"
        },
        seriesColors: _colorList
    });
}
function getColumnHighChartForReports(controlId, chartType, xAxisData, seriesData, chartTitle, _colorList) {
    //var _colorList = ["#48D1CC", "#f44455", "#6cc788", "#6887ff", "#fcc100", "#f77a99", "#a88add", "#0cc2aa", "#2196f3", "#8bc34a", "#B0171F", "#DB7093", "#DC143C", "#FFAEB9", "#8B475D", "#FF3E96", "#FF1493", "#CD1076", "#9400D3", "#0000FF", "#8B8B00", "#00008B", "#6495ED", "#00BFFF", "#00F5FF", "#00FA9A", "#008B45", "#EEEE00", "#EE4000", "#8E388E", "#8E8E38", "#C67171"];    
    $("#" + controlId).kendoChart({
        legend: {
            visible: false
        },
        title: {
            text: chartTitle
        },
        seriesDefaults: {
            type: chartType,
            labels: {
                visible: true,
                format: "#= category #: #= value #",
                background: "transparent"
            }
        },
        series: [{
            data: seriesData
        }],
        categoryAxis: {
            categories: xAxisData,
            labels: {
                rotation: -20,
            }
        },
        tooltip: {
            visible: true,
            position: "top",
            template: "#= category #: #= value #"
        },
        seriesColors: _colorList
    });
}

// Disable Space in Form TextBox First Digit
function disableFirstSpace(e) {
    if (e.which === 32 && e.target.selectionStart === 0) {
        e.preventDefault();
    }
}