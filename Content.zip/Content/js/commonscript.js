﻿$(document).ready(function () {
    height();
});
$(window).on('resize', function () {
    height();
});
function height() {
    var $leftTabs = $(".sidebar");
    var $windowtHeight = $(window).height();
    var $leftTabsHeight = $(".content-wrapper").height();
    if ($leftTabsHeight > $windowtHeight) {
        $leftTabs.height($leftTabsHeight - 80);
    }
    else {
        $leftTabs.height($windowtHeight - 50);
    }

}


setTimeout(function () {
    $('#fileLoader').change(function () {
        var filepath = this.value;
        var m = filepath.match(/([^\/\\]+)$/);
        var filename = m[1];
        $('#filename').html(filename);
    });
}, 3000);

