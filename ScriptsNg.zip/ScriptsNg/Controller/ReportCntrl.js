﻿app.controller("ReportCntrl", function ($scope) {
    debugger
    var ApiUrlPath = ApiUrl;

    $scope.mainGridOptions = {

        sortable: true,
        //height: 600,
        pageable: {
            pageSize: GridPageSize, refresh: true
        },
        filterable: true,
        toolbar: kendo.template($("#template").html()),
          excel: {
            allPages: true,
          },
         excelExport: function(e) {
            var date = new Date();
            var dateName = kendo.toString(date, "g");
            var fileName = "Report " + dateName;
            e.workbook.fileName = fileName;
          },
          pdf: {
            allPages: true,
            //paperSize: "A4",
            landscape: true,
            //template: $("#page-template").html()
          },

        columns: [
            {
                field: "AccountNo",
                title: "Account No",
                width: 120,
                filterable: false
            },
            {
                field: "CustomerId",
                title: "Customer Id",
                width: 120,
                filterable: false
            },
            {
                field: "Name",
                title: "Name",
                width: 140,
                filterable: false
            },
            {
                field: "BranchCode",
                title: "Branch Code",
                width: 100,
                filterable: false
            },
            {
                field: "DateOfLoan",
                title: "Date Of Loan",
                template: "#=  (DateOfLoan == null)? '' : kendo.toString(kendo.parseDate(DateOfLoan, 'yyyy-MM-dd'), 'yyyy-MM-dd') #",
                width: 100,
                filterable: false
            },
            {
                field: "LoanAmount",
                title: "Loan Amount",
                width: 120,
                filterable: false
            },

            {
                field: "FatherOrSpouseName",
                title: "Father/Spouse Name",
                width: 170,
                filterable: false
            },
            {
                field: "Constitution",
                title: "Constitution",
                width: 140,
                filterable: false
            },
            {
                field: "BorrowerOrGuarantor",
                title: "Borrower/Guarantor",
                width: 170,
                filterable: false
            },
            {
                field: "Address1",
                title: "Address 1",
                width: 120,
                filterable: false
            },
            {
                field: "Address2",
                title: "Address 2",
                width: 120,
                filterable: false
            },
            {
                field: "Pincode",
                title: "Pincode",
                width: 80,
                filterable: false
            },
            {
                field: "MobileNumber",
                title: "Mobile Number",
                width: 120,
                filterable: false
            },
             {
                 field: "PAN",
                 title: "Pan",
                 width: 100,
                 filterable: false
             },
            {
                field: "IdProof1",
                title: "Id Proof 1",
                width: 120,
                filterable: false
            },
            {
                field: "IdProof2",
                title: "Id Proof 2",
                width: 120,
                filterable: false
            },
            
           
           {
                field: "Type",
                title: "Loan Type",
                width: 130,
                filterable: false
            },
          
            {
                field: "dept",
                title: "Department",
                width: 150,
                filterable: false
            },
        {
            field: "Remarks",
        title: "Remarks",
    width: 200,
    filterable: false
}

        ],

        dataSource:
            {
                transport: {
                    batch: true,
                    read: {
                        type: "POST",
                        showloader: true,
                        url: function () {
                            return "api/Report/GetReportByYear"
                        },
                        complete: function (response) {
                            hideloader();
                        }
                    },

                    parameterMap: function (options, operation) {
                        var opt = {};
                        opt = options;
                        opt.search = $scope.SearchBox;
                        opt.year = $scope.year;
                        opt.loanTypeId = $scope.LoanTypeId;
                        opt.departmentId = $scope.DepartmentId;
                        return opt;
                    }
                },

                schema:
                {
                    model:
                    {
                        id: "DefaulterId"
                    },
                    data: function (response) {
                        if (response) {
                            debugger
                            $scope.TotalRows = response.Total;
                            return response.Result;
                        }
                        return [];
                    },
                    total: 'Total',
                },

                //pageSize: GridPageSize,
                serverPaging: true,
                //serverSorting: true,
                //serverFiltering: true,
            }


    };

    //year based filter
    $scope.YearFilter = function () {
        $("#grid").data("kendoGrid").dataSource.read();
    }

    //Branch wise filter
    $scope.Search = function () {
        $("#grid").data("kendoGrid").dataSource.read();
    }

    //loan type data
    $scope.LoanTypeData = {
        serverFiltering: true,
        transport: {
            read: {
                type: "POST",
                url: "/api/Defaulter/GetLoanType",
            }
        }
    }

    $scope.LoanTypeFilter = function () {
        $("#grid").data("kendoGrid").dataSource.read();
    }

    //Department Data

    $scope.DepartmentData = {
        serverFiltering: true,
        transport: {
            read: {
                type: "POST",
                url: "api/Defaulter/DepartmentData",
            }
        }
    }

    $scope.DepartmentFilter = function () {
        $("#grid").data("kendoGrid").dataSource.read();
    }



});

