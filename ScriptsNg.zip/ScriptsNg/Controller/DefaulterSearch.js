﻿app.controller("GridCtrl", function ($scope) {
    var ApiUrlPath = ApiUrl;
});


$(function () {

    var table = $('#tblCustomer').DataTable({
        "paging": false,
        "info": false,
        "bFilter": false,
        "ordering": false
    });
    $('#tblCustomer_wrapper').hide();


    $("#btnSearch").click(function () {
        showloader();
            setTimeout(function () {
                if ($('#txtName').val() == '' && $('#txtCustomer').val() == '' && $('#txtPAN').val() == '' && $('#txtIdProof2').val() == '') {
                $('#tblCustomer_wrapper').hide();
                $('#resultsDiv').html("No data available");
                WarnMessage('Please enter any data.');
                hideloader();
            }
            else {
                $('#tblCustomer_wrapper').show();
                $('#resultsDiv').html("Search Results:");
                tblFormate();
                hideloader();
            }
        }, 500);
        
    });
});


function tblFormate() {
    debugger;
    $.ajax({
        url: "api/Defaulter/GetAllSearch",
        type: "GET",
        contentType: 'application/json; charset=utf-8',
        data: {
            name: $('#txtName').val(),
            customerid: $('#txtCustomer').val(),
            pan: $('#txtPAN').val(),
            IdProof2: $('#txtIdProof2').val()
        },
        async: false,
        success: function (data) {
            $('#tblCustomer tbody').html("");
            if (data.length != 0) {

                $('#resultsDiv').html("Search Results");
                $('#tblCustomer_wrapper').show();
            }
            else {
                $('#tblCustomer_wrapper').hide();
                $('#resultsDiv').html("No data available!");
            }
            var tr = "";
            for (var i = 0; i < data.length; i++) {
                tr = tr + "<tr>";
                tr = tr + "<td>" + data[i].Name + "</td>";
                tr = tr + "<td>" + data[i].CustomerId + "</td>";
                if (data[i].BranchCode != null)
                    tr = tr + "<td>" + data[i].BranchCode + "</td>";
                else
                    tr = tr + "<td>&nbsp;</td>";
                if (data[i].DateOfLoan != null)
                    tr = tr + "<td>" + data[i].DateOfLoan.substr(0, 10) + "</td>";
                else
                    tr = tr + "<td>&nbsp;</td>";
                if (data[i].LoanAmount != null)
                    tr = tr + "<td ><span style='background-color:#9C27B0;border-radius:7px;color:white; padding:9px;display: block; text-align: center;margin:0 20px;' class='loanamount '>Amount  <span style='font-weight: bold;padding-left: 5PX; font-size: large;    vertical-align: middle;'> " + parseFloat(data[i].LoanAmount).toFixed(2) + "</span></span></td>";
                else
                    tr = tr + "<td ><span style='background-color:#9C27B0;border-radius:7px;color:white; padding:9px;display: block; text-align: center;margin:0 20px;' class='loanamount '>Amount  <span style='font-weight: bold;padding-left: 5PX; font-size: large;    vertical-align: middle;'> " + "0.00" + "</span></span></td>";
                tr += "<td onclick='openModal(\"" + data[i].AccountNo + "," + data[i].Address1 + "," + data[i].Address2 + "," + data[i].BorrowerOrGuarantor + "," + data[i].BranchCode + "," + data[i].Constitution + "," + data[i].DateOfLoan + "," + data[i].DefaultType + "," + data[i].FatherOrSpouseName + "," + data[i].IdProof1 + "," + data[i].IdProof2 + "," + data[i].LoanAmount + "," + data[i].Name + "," + data[i].MobileNumber + "," + data[i].PAN + "," + data[i].Pincode + "," + data[i].Region + "," + data[i].Remarks + "," + data[i].Type + "," + data[i].dept + "\")'><span style='background-color:#9C27B0;border-radius:7px;color:white; padding:9px;display: block; text-align: center;margin:0 20px;cursor:pointer'>View</td>";
                tr = tr + "</tr>";
            }
            $('#tblCustomer').append(tr);
            $('#tblCustomer td').css('width', '20%');
            if (data.length == 0) {
                $('#tblCustomer_wrapper').hide();
                $('#resultsDiv').html("No data available!");
            }
            else {
                $('#resultsDiv').html("Search Results");
            }
        },
        error: function (xhr) {
            WarnMessage('No Valid Data');
        }
    });
}


function openModal(dataObj) {
    debugger
    var dataArray = dataObj.split(',');
    
    var str = dataArray[6];
    var pincode = dataArray[15];

    if (str == "null" || str == "") {
        var formatdate = '';
    } else {
        var date = new Date(str);
        var formatdate = date.toISOString().slice(0, 10); 
    }
    

    if (pincode == "null") {
        pincode = "";
    }
  

    

    var modalHtml = "<table>";
    modalHtml += "<tr><td>AccountNo</td><td>" + dataArray[0] + "</td></tr>";
    modalHtml += "<tr><td>Address1</td><td>" + dataArray[1] + "</td></tr>";
    modalHtml += "<tr><td>Address2</td><td>" + dataArray[2] + "</td></tr>";
    modalHtml += "<tr><td>Borrower Or Guarantor</td><td>" + dataArray[3] + "</td></tr>";
    modalHtml += "<tr><td>Branch Code</td><td>" + dataArray[4] + "</td></tr>";
    modalHtml += "<tr><td>Constitution</td><td>" + dataArray[5] + "</td></tr>";
    modalHtml += "<tr><td>Date Of Loan</td><td>" + formatdate + "</td></tr>";
    modalHtml += "<tr><td>Father or Spouse Name</td><td>" + dataArray[8] + "</td></tr>";
    modalHtml += "<tr><td>Id Proof 1</td><td>" + dataArray[9] + "</td></tr>";
    modalHtml += "<tr><td>Id Proof 2</td><td>" + dataArray[10] + "</td></tr>";
    modalHtml += "<tr><td>Loan Type</td><td>" + dataArray[18] + "</td></tr>";
    modalHtml += "<tr><td>Loan Amount</td><td>" + dataArray[11] + "</td></tr>";
     modalHtml += "<tr><td>Mobile Number</td><td>" + dataArray[13] + "</td></tr>";
    modalHtml += "<tr><td>PAN</td><td>" + dataArray[14] + "</td></tr>";
    modalHtml += "<tr><td>Pincode</td><td>" + pincode + "</td></tr>";
    modalHtml += "<tr><td>Region</td><td>" + dataArray[16] + "</td></tr>";
    modalHtml += "<tr><td>Remarks</td><td>" + dataArray[17] + "</td></tr>";
    modalHtml += "<tr><td>Department</td><td>" + dataArray[19] + "</td></tr>";
    modalHtml += "</table>";
    $('.modal-title').html("Details of " + dataArray[12]);
    $('.modal-body').html(modalHtml);
    $("#myModal").modal();
}

