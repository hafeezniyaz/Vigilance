﻿
app.controller("ChartCtrl", function ($scope) {
    $scope.onSeriesHover = function (e) {
        console.log(kendo.format("event :: seriesHover ({0} : {1})", e.series.name, e.value));
    };

    //year based filter
    $scope.YearFilter = function () {
       
        getBranchdefaulterdata();
    }


    $scope.YearFilter1 = function () { 
        getloandefaulterdata();
    }



    $scope.YearFilter2 = function () {
        getDepartmentdefaulterdata();
    }



    

    //Department data
    $scope.DepartmentData = {
        serverFiltering: true,
        transport: {
            read: {
                type: "POST",
                url: "api/Defaulter/DepartmentData",
            }
        }
    }
});


var branchcodes = [];
var counts = [];

var loantypeids = [];
var countlones = []; 

var years = [];
var yearcounts = [];



function getBranchdefaulterdata() {

    branchcodes = [];
    counts = [];
 debugger
    var years = $('#yeardrop').find(":selected").text();
    var departments = ($('#deptdrop2').find(":selected").text() == "" || $('#deptdrop2').find(":selected").text() == "--select--") ? $('#deptdrop2').find(":selected").text() : $('#deptdrop2').find(":selected").val();


    $.ajax({
        url: "api/Dashboard/GetAllBranch",
        type: "GET",
        contentType: 'application/json; charset=utf-8',
        data: {
            yeard: years,
            deptd: departments == "" || departments == "--select--" ? 0 : parseInt(departments)
        },
        async: false,
        success: function (data) {
         
            data.forEach(function (index, array) {
               
                branchcodes.push(index.branchcode);
                counts.push(index.Count);
            });

           

        },
        error: function (xhr) {

        }
    });

    //branchcode chart
    $("#branchcodechart").kendoChart({
        title: {
            fill: "blue",
            align: "left",
            color: "",
            font: "bold 15px sans-serif",
            margin: {
                bottom: 50,
                right: 10
            }

        },

        legend: {
            position: "bottom"
        },
        series: [{
            labels: {
                visible: true,
                position: "top",
                padding: {
                    top: -20
                },
               
            },
            color: '#ad58bc',
            tooltip: {
                visible: true,
                font: "20px sans-serif",                           
            },
            name: "Defaulter Count based on Branch Code",
            data: counts

        }],
        categoryAxis: {
            categories: branchcodes
        },

    });

}

function getDepartmentdefaulterdata() {
    debugger
    var depttypeids = [];
    var countdepts = [];

    var years = $('#yeardrop2').find(":selected").text();

    $.ajax({
        url: "api/Dashboard/GetAllDepartment",
        type: "GET",
        contentType: 'application/json; charset=utf-8',
        data: {
            yeard: years
        },
        async: false,
        success: function (data) {

            data.forEach(function (index, array) {

                depttypeids.push(index.name);
                countdepts.push(index.departmentCount);
            });



        },
        error: function (xhr) {

        }
    });

    //department chart
    $("#departmentchart").kendoChart({
        title: {
            align: "left",
            color: "#9c27b0",
            font: "bold 15px sans-serif",
            margin: {
                bottom: 50,
                right: 10
            }
        },
        legend: {
            position: "bottom"
        },
        series: [{
            labels: {
                visible: true,
                position: "top",
                padding: {
                    top: -20,
                },

            },
            color: '#ad58bc',
            tooltip: {
                visible: true,
                font: "20px sans-serif",

            },
            name: "Defaulter count based on Department",
            data: countdepts

        }],
        categoryAxis: {
            categories: depttypeids
        },

    });

}

function getloandefaulterdata() {
    debugger
    var loantypeids = [];
    var countlones = [];
   
    var years = $('#yeardrop1').find(":selected").text();
    var departments = ($('#deptdrop1').find(":selected").text() == "" || $('#deptdrop1').find(":selected").text() == "--select--") ? $('#deptdrop1').find(":selected").text():   $('#deptdrop1').find(":selected").val() ;

    $.ajax({
        url: "api/Dashboard/GetAllLoan",
        type: "GET",
        contentType: 'application/json; charset=utf-8',
        data: {
            yeard: years,
            deptd: departments == "" || departments == "--select--" ? 0 : parseInt(departments)
        },
        async: false,
        success: function (data) {
         
            data.forEach(function (index, array) {
               
                loantypeids.push(index.type);
                countlones.push(index.loanCount);
            });

           

        },
        error: function (xhr) {

        }
    });

    //loan chart
    $("#loanchart").kendoChart({
        title: {
            align: "left",
            color: "#9c27b0",
            font: "bold 15px sans-serif",
            margin: {
                bottom:20,
                right: 10
            }         
        },
        legend: {
            position: "bottom"
        },
        series: [{
            labels: {
                visible: true,
                position: "top",
                padding: {
                    top: -20
                },


            },
            color: '#ad58bc',
            tooltip: {
                visible: true,
                font: "20px sans-serif",

            },
            name: "Defaulter count based on Loan Type",
            data: countlones

        }],
        categoryAxis: {
            categories: loantypeids,

                labels: {
                   rotation:-25
            },
        },

    });

}


$(document).ready(function () {
    debugger

    getBranchdefaulterdata();
    getloandefaulterdata();
  
    var monthdata = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec'];
    var yearDatas = [];

    $.ajax({
        url: "api/Dashboard/GetAllDefaultersYearAndMonthWise",
        type: "POST",
        contentType: 'application/json; charset=utf-8',      
        async: false,
        success: function (data) {
            debugger
            if (data.length > 0)
            {       
                data.forEach(function (index, array) {

                    var yeardataArray = [];
                    yeardataArray.push(index.January);
                    yeardataArray.push(index.February);
                    yeardataArray.push(index.March);
                    yeardataArray.push(index.April);
                    yeardataArray.push(index.May);
                    yeardataArray.push(index.June);
                    yeardataArray.push(index.July);
                    yeardataArray.push(index.August);
                    yeardataArray.push(index.September);
                    yeardataArray.push(index.October);
                    yeardataArray.push(index.November);
                    yeardataArray.push(index.December);
                   
                    yearDatas.push({
                        tooltip: {
                            visible: true,
                            font: "20px sans-serif",

                        },
                        data: yeardataArray,
                        name: index.years
                    });

                });
            }
        },
        error: function (xhr) {

        }
    });

    $("#yearchart").kendoChart({
        seriesColors: ["#9b59b6", "#6ab04c", "#be2edd", "#c44569","#6ab04c", "#686de0", "#ad58bc", "#22a6b3", "#B33771", "#FD7272", "#F97F51"],
        title: {
            align: "left",
            color: "#9c27b0",
            font: "bold 15px sans-serif",
            margin: {
                bottom: 20,
                right: 10
            }
        },
        legend: {
            position: "bottom"
        },
        seriesDefaults: {
            type: "line"
        },
        series:  yearDatas,
        valueAxis: {
            labels: {
                format: "{0}",
            }
        },
        categoryAxis: {
            categories: monthdata
        }
    });

    getDepartmentdefaulterdata();
})


