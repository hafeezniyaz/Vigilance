﻿
app.controller("GridCtrl", function ($scope, CustomerService) {
    var ApiUrlPath = ApiUrl;
    var baseUrl = ApiUrlPath + "api/Defaulter/SaveCustomer";
    var updateUrl = ApiUrlPath + "api/Defaulter/UpdateCustomer";
    $scope.Save = "Save";
    $scope.IsVisibleFirstName = false;

    $scope.mainGridOptions = {
        editable: {
            mode: "popup",
            template: kendo.template($("#EditTemplate").html()),
            onedit: ""
        },
        sortable: true,
        scrollable: true,
        width: 1700,
        resizable: false,
        pageable: { pageSize: GridPageSize, refresh: true, buttonCount: 3 },
        filterable: true,
        save: function () {
            this.refresh();
        },
        toolbar: kendo.template($("#template").html()),

        columns: [
        {
            field: "AccountNo",
            title: "Account No",
            filterable: false
        },
        {
            field: "CustomerId",
            title: "Customer Id",
            filterable: false
        },
        {
            field: "Name",
            title: "Name",
            filterable: false
        },
        {
            field: "BranchCode",
            title: "Branch Code",
            filterable: false
        },
        {
            field: "DateOfLoan",
            title: "Date Of Loan",
            template: "#=  (DateOfLoan == null)? '' : kendo.toString(kendo.parseDate(DateOfLoan, 'yyyy-MM-dd'), 'yyyy-MM-dd') #",
            filterable: false
        },
        {
            field: "LoanAmount",
            title: "Loan Amount",
            filterable: false
        },

        {
            field: "dept",
            title: "Department",
            filterable: false
        },

        {
            field: "Type",
            title: "Loan Type",
            filterable: false
        },
        {
            field: "PAN",
            title: "Pan",
            filterable: false
        },
        {
            command: [
                {
                    name: "edit", text: { edit: "" }
                },

               {
                   name: "remove",
                   text: "&#x2716;",
                   click: deleteItem,
               }
            ]

        }],


        dataSource:
            {
                transport: {
                    batch: true,
                    read: {
                        type: "POST",
                        showloader: true,
                        url: function () {
                            return "api/Defaulter/GetAll"
                        },
                        complete: function (response) {
                            hideloader();
                        }
                    },

                    parameterMap: function (options, operation) {
                        var opt = {};
                        opt = options;
                        opt.search = $scope.SearchBox;
                        opt.year = $scope.year;
                        return opt;
                    },

                    update:
                    {
                        url: "api/Defaulter/UpdateCustomer",
                        type: "POST",
                    },

                    destroy:
                    {
                        url: "api/Defaulter/DeleteCustomer",
                        type: "POST" 
                    },
                },
                pageSize: GridPageSize,
                serverPaging: true,
                schema:
                {
                    model:
                    {
                        id: "DefaulterId",
                        fields: {
                            AccountNo: { editable: true, type: "string", validation: { required: true } },
                            CustomerId: { editable: true, type: "string", validation: { required: true } },
                            Name: { editable: true, type: "string" },
                            BranchCode: { editable: true, type: "string" },
                            DateOfLoan: { editable: true, type: "string" },
                            LoanAmount: { editable: true, type: "string" },
                            FatherOrSpouseName: { editable: true, type: "string" },
                            Constitution: { editable: true, type: "string" },
                            BorrowerOrGuarantor: { editable: true, type: "string" },
                            Address1: { editable: true, type: "string" },
                            Address2: { editable: true, type: "string" },
                            Pincode: { editable: true, type: "string" },
                            MobileNumber: { editable: true, type: "string" },
                            PAN: { editable: true, type: "string" },
                            IdProof1: { editable: true, type: "string" },
                            IdProof2: { editable: true, type: "string" },
                            IdProof2: { editable: true, type: "string" },
                            DepartmentId: { editable: true, type: "string" },
                            LoanTypeId: { editable: true, type: "string" },
                            Remarks: { editable: true, type: "string" },
                            DefaultTypeId: { editable: true, type: "string" },
                            RegionId: { editable: true, type: "string" }
                        }
                    },
                    data: function (response) {
                        if (response) {
                            $scope.TotalRows = response.Total;
                            return response.Result;
                        }
                        return [];
                    },
                    total: 'Total',
                }
            }


    };

    function deleteItem(e) {
        var dataItem = this.dataItem($(e.currentTarget).closest("tr"));
        $.when(showConfirmationActiveWindow('<h5>Are you sure you want to delete this record ?</h5>')).then(function (confirmed) {
            if (confirmed) {
                showloader();
                var grid = $("#grid").data("kendoGrid");
                grid.dataSource.remove(dataItem);
                grid.dataSource.sync();
                grid.refresh();
                hideloader();
                SetMessage('Delete');
            }
            else {
                hideloader();
                return false;
            }
        });
    }

    $scope.UpdateCustomer = function () {
        var DefaulterId = $("#DefaulterId").val();
        var AccountNo = $("#AccountNo").val();
        var CustomerId = $('#CustomerId').val();
        var Name = $("#Name").val();
        var BranchCode = $("#BranchCode").val();
        var DateOfLoan = $("#DateOfLoan").val();
        var LoanAmount = $("#LoanAmount").val();
        var FatherOrSpouseName = $("#FatherOrSpouseName").val();
        var Constitution = $("#Constitution").val();
        var BorrowerOrGuarantor = $("#BorrowerOrGuarantor").val();
        var Address1 = $("#Address1").val();
        var Address2 = $("#Address2").val();
        var Pincode = $("#PinCode").val();
        var MobileNumber = $("#MobileNumber").val();
        var PAN = $("#PAN").val();
        var IdProof1 = $("#IdProof1").val();
        var IdProof2 = $("#IdProof2").val();
        var LoanTypeId = $("#LoanTypeId").val();
        var DepartmentId = $("#DepartmentId").val();
        var Remarks = $("#Remarks").val();
        var DefaultTypeId = $("#DefaultTypeId").val();
        var RegionId = $("#RegionId").val();


        var update = {
            DefaulterId: DefaulterId,
            AccountNo: AccountNo,
            CustomerId: CustomerId,
            Name: Name,
            BranchCode: BranchCode,
            DateOfLoan: DateOfLoan,
            LoanAmount: LoanAmount,
            FatherOrSpouseName: FatherOrSpouseName,
            Constitution: Constitution,
            BorrowerOrGuarantor: BorrowerOrGuarantor,
            Address1: Address1,
            Address2: Address2,
            Pincode: Pincode,
            MobileNumber: MobileNumber,
            PAN: PAN,
            IdProof1: IdProof1,
            IdProof2: IdProof2,
            LoanTypeId: LoanTypeId,
            DepartmentId: DepartmentId,
            Remarks: Remarks,
            DefaultTypeId: DefaultTypeId,
            RegionId: RegionId
        };


        function Validate() {
            debugger
            var flag = 0;
            var MobileNumberRegEx = /^[6-9]\d{9}$/;

            if (update.AccountNo == undefined) {
                $scope.AccountNoValidation = "Please Enter Account No"
                flag = 1;
            }
            else if (update.AccountNo == "") {
                $scope.AccountNoValidation = "Please Enter Account No"
                flag = 1;
            }
            else {
                $scope.AccountNoValidation = "";
            }


            if (update.Name == undefined) {
                $scope.NameValidation = "Please Enter Name"
                flag = 1;
            }
            else if (update.Name == "") {
                $scope.NameValidation = "Please Enter Name"
                flag = 1;
            }
            else {
                $scope.NameValidation = "";
            }

            if (flag == 1)
                return false;
            else
                return true;
        }

        if (Validate() == true) {
            showloader();

            if (update.DateOfLoan != null) {
                var dateOut = update.DateOfLoan.split("/");
                update.DateOfLoan = new Date(dateOut[1] + "/" + dateOut[0] + "/" + dateOut[2]);
            }

            var UpdateCustomer = CustomerService.post(updateUrl, update);
            UpdateCustomer.then(function (response) {
                hideloader();
                if (response.data == "UserExists") {
                    WarnMessage('Account No already exists');
                    return false;
                }
                if (response.data.toLowerCase() == "true") {
                    $("#grid").data("kendoGrid").dataSource.read();
                    SetMessage('Update');
                }
                else {
                    SetMessage('Error');
                }

            });
        }
    }


    var currentDate = new Date();

    $scope.SaveCustomer = function () {

        var customer = {
            DefaulterId: $scope.DefaulterId,
            AccountNo: $scope.AccountNo,
            CustomerId: $scope.CustomerId,
            Name: $scope.Name,
            BranchCode: $scope.BranchCode,
            DateOfLoan: $scope.DateOfLoan,
            LoanAmount: $scope.LoanAmount,
            FatherOrSpouseName: $scope.FatherOrSpouseName,
            Constitution: $scope.Constitution,
            BorrowerOrGuarantor: $scope.BorrowerOrGuarantor,
            Address1: $scope.Address1,
            Address2: $scope.Address2,
            PinCode: $scope.PinCode,
            MobileNumber: $scope.MobileNumber,
            PAN: $scope.PAN,
            IdProof1: $scope.IdProof1,
            IdProof2: $scope.IdProof2,
            LoanTypeId: $scope.LoanTypeId,
            DepartmentId: $scope.DepartmentId,
            DefaultTypeId: $scope.DefaultTypeId,
            RegionId: $scope.RegionId,
            Remarks: $scope.Remarks,
            IsActive: 1,
            IsDeleted: 0,
            CreatedDate: currentDate,
            LastModifiedDate: currentDate,
            CreatedById: 1,
            LastModifiedById: 1
        }

        window.KendoFormValidation = function () {
            var flag;

            if (customer.AccountNo == "") {
                $scope.AccountNoValidation = "Please Enter Account No"
                flag = 1;
            }
            else if (customer.AccountNo == undefined) {
                $scope.AccountNoValidation = "Please Enter Account No"
                flag = 1;
            }
            else {
                $scope.AccountNoValidation = "";
            }

            if (customer.Name == "") {
                $scope.NameValidation = "Please Enter Name"
                flag = 1;
            }
            else if (customer.Name == undefined) {
                $scope.NameValidation = "Please Enter Name"
                flag = 1;
            }
            else {
                $scope.NameValidation = "";
            }

            if (flag == 1)
                return false;
            else
                return true;

        }


        if ($scope.Save == "Save") {
            debugger
            if (KendoFormValidation() == true) {
                showloader();

                if (customer.DateOfLoan != null) {
                    var dateOut = customer.DateOfLoan.split("/");
                    customer.DateOfLoan = new Date(dateOut[1] + "/" + dateOut[0] + "/" + dateOut[2]);
                }

                var saveCustomer = CustomerService.post(baseUrl, customer);
                saveCustomer.then(function (response) {
                    hideloader();
                    if (response.data == "UserExists") {
                        WarnMessage('Account No, Customer Id or PAN number already exists');
                        return false;
                    }
                    if (response.data.toLowerCase() == "true") {
                        $("#grid").data("kendoGrid").dataSource.read();
                        SetMessage('Save');
                        $scope.clear();
                        $(".win1").data("kendoWindow").close();
                    }
                    else {
                        SetMessage('Error');
                    }

                });

            }

        }
    }

    $scope.clear = function () {
        $scope.AccountNo = null;
        $scope.CustomerId = null;
        $scope.Name = null;
        $scope.BranchCode = null;
        $scope.DateOfLoan = null;
        $scope.LoanAmount = null;
        $scope.FatherOrSpouseName = null;
        $scope.Constitution = null;
        $scope.BorrowerOrGuarantor = null;
        $scope.Address1 = null;
        $scope.Address2 = null;
        $scope.PinCode = null;
        $scope.MobileNumber = null;
        $scope.PAN = null;
        $scope.IdProof1 = null;
        $scope.IdProof2 = null;
        $scope.LoanTypeId = null;
        $scope.Remarks = null;
        $scope.AccountNoValidation = null;
        $scope.CustomerIdValidation = null;
        $scope.NameValidation = null;
        $scope.BranchCodeValidation = null;
        $scope.DateOfLoanValidation = null;
        $scope.LoanAmountValidation = null;
        $scope.FatherOrSpouseNameValidation = null;
        $scope.ConstitutionValidation = null;
        $scope.BorrowerOrGuarantorValidation = null;
        $scope.Address1Validation = null;
        $scope.Address2Validation = null;
        $scope.PinCodeValidation = null;
        $scope.MobileNumberValidation = null;
        $scope.PanValidation = null;
        $scope.IdProof1Validation = null;
        $scope.IdProof2Validation = null;
        $scope.ConflictError = null;
    }


    $scope.LoanTypeData = {
        serverFiltering: true,
        transport: {
            read: {
                type: "POST",
                url: "api/Defaulter/GetLoanType",
            }
        }
    }


    $scope.DepartmentData = {
        serverFiltering: true,
        transport: {
            read: {
                type: "POST",
                url: "api/Defaulter/DepartmentData",
            }
        }
    }

    $scope.DefaultTypeData = {
        serverFiltering: true,
        transport: {
            read: {
                type: "POST",
                url: "api/Defaulter/DefaultTypeData",
            }
        }
    }

    $scope.RegionData = {
        serverFiltering: true,
        transport: {
            read: {
                type: "POST",
                url: "api/Defaulter/RegionData",
            }
        }
    }

    $scope.EditClose = function () {
        $scope.clear();
        $("#grid").data("kendoGrid").dataSource.read();
        $(".k-widget.k-window").data("kendoWindow").close();
    }

    $scope.Search = function () {
        $("#grid").data("kendoGrid").dataSource.read();
    }

    $scope.YearFilter = function () {
        $("#grid").data("kendoGrid").dataSource.read();
    }

    $scope.uploadFiles = function () {
        showloader();
        var data = new FormData();
        data.append("uploadedFile", $("#fileLoader")[0].files[0]);
        var objXhr = new XMLHttpRequest();
        objXhr.addEventListener("load", uploadComplete, false)

        function uploadComplete(evt) {
            debugger
            var result = objXhr.responseText.substr(1, objXhr.responseText.length - 2);

            if (result == "nofile") {
                WarnMessage("Please select Excel file.");
            }
            else if (result == "norows") {
                WarnMessage("Please add atleast one record.");
            }
            else if (result == "formatError") {
                WarnMessage("Please upload a excel file.");
            }
            else if (result.substr(0, 10) == "emptyfield") {
                WarnMessage(result.substr(11, result.length - 1));
            }
            else if (result.substr(0, 8) == "Invalid1") {
                WarnMessage(result.substr(8, result.length - 1));
            }
            else if (result.substr(0, 8) == "Invalid2") {
                WarnMessage(result.substr(8, result.length - 1));
            }
            else if (result.substr(0, 8) == "Invalid3") {
                WarnMessage(result.substr(8, result.length - 1));
            }
            else if (result.substr(0, 8) == "Invalid4") {
                WarnMessage(result.substr(8, result.length - 1));
            }
            else if (result.substr(0, 8) == "Invalid5") {
                WarnMessage(result.substr(8, result.length - 1));
            }

            else if (result == "true") {
                CustomMessage("Uploaded", "Excel data uploaded successfully.");
                $("#grid").data("kendoGrid").dataSource.read();
                $(".win2").data("kendoWindow").close();
            }

            else if (result == "false")
                SetMessage('Error')

            else if (result == "invalidargs")
                WarnMessage("Account number is blank  !!");

            hideloader();
        }

        objXhr.open("POST", ApiUrlPath + 'api/CustomerDetails/FileUpload');
        objXhr.send(data);
    }

    function transferComplete(e) {
        SetMessage('Save');
        window.location.reload();
    }


    $scope.downloadTemplate = function () {
        window.location = '/CustomerDetails/downloadTemplate';
    }



}).service('CustomerService', function ($http) {
        var urlGet = '';
        this.post = function (apiRoute, Model) {
            var request = $http({
                method: "post",
                url: apiRoute,
                data: Model
            });
            return request;
        }
    });



function grid_edit(e) {
    var dt = $("input[name='DateOfLoan']").val()
    setTimeout(function () {
        $("input[name='DateOfLoan']").val(dt)
    }, 200);
}


window.onload = function (e) {
    var grid = $("#grid").data("kendoGrid");
    grid.bind("edit", grid_edit);

    $("#grid").kendoTooltip({
        filter: ".k-grid-edit",
        content: function (e) {
            return "Edit";
        }
    });

    $("#grid").kendoTooltip({
        filter: ".k-grid-remove",
        content: function (e) {
            return "Delete";
        }
    });

}


